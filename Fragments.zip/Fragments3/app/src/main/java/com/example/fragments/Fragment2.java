package com.example.fragments;

import androidx.fragment.app.Fragment;

public class Fragment2 extends Fragment {
}
