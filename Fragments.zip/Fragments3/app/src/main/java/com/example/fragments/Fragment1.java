package com.example.fragments;

import androidx.fragment.app.Fragment;

public class Fragment1 extends Fragment {
}
